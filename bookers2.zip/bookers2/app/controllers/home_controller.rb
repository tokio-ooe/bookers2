class HomeController < ApplicationController
  def home
  end

  def about
  end
end
