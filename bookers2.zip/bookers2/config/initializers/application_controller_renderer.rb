# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '4c533b40d6e8a5cd8ccbde769917f1c1498da1fece699bef9a0d7fab0dbe832820991141f23326077027b22b63c52922a428cadcf06124ed58feff4241f2f607'
